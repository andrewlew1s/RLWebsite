export default {
	text: `Old words sound beautiful
Because we don’t know what they mean.

But then you unwrapped them onstage,
Blue cloths unwound from your arms.

Your conquerors they took your lips, your eyes,
Your gods, but then you held each other,

Not killed by guns and the boys they bear
But shattered beyond all signs of breaking.

O Helen, were your feet broken
From the ground, was your waist chained,
Were you raped with the dancing girls?

You buried your Astyanax
In a cardboard box. Time is collapsed.

There is no story but this story telling
Its retelling, Troy is always falling.`,
	title: 'Ilium'
};
