export default {
	text: `She holds the knife over red flesh,
Its roundness straining at thin skin.
She nicks with the serrated blade its edge,
And pauses, and slices her first incision.

The new halves split, peeling apart,
Their several hearts displaying
Great symmetry and difference,
With a pip more here and there.

Two hemipsheres. With every cut
Another and another and another,
Smaller, smaller, smaller, less to hold,
Less space to cut the next from.`,
	title: 'The Decision'
};
