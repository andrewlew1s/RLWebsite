export default {
	title: 'It',
	video: 'https://player.vimeo.com/video/267116502'
};
