const image = require('../images/20Tourists.png');

export default {
	title: '20 Tourists',
	image
};
