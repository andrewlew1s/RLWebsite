export default {
	text: `In between hunts, when I lie in the grasses
And practise the stillness of death,
I have been thinking hard.
And I believe, Father, that what is gone is certitude.
We learnt the loss of you in between licks,
When we asked where our bull elephant,
Our antlered stag, our spring-spout was.
Mother said you were a wanderer, that all men are,
You were never going to be around for long.
I do my best without you. I rise
As I believe you rose, as I saw Mother
Surge, all dappled haunches, in the den.
Like her, only heavier. For I think you would stand
With all the thunder-strength of muscled cloud.
Now I am big as she said you were and I would be,
Eye-level with the lightning-riven tree.
But she was wrong as well, said you were wandering
Through forests longer than the sky is high,
Forests full of other fathers. I have looked for you.
I have walked the orange day and the black night.
But I could not even find the forests, could not
Even find the way to you. All I found was men
And the carcasses of lands they leave behind.
Father I am afraid for you, lost somewhere
I cannot help, somewhere I cannot even see.
But Father, I am still more afraid for me.`,
	title: 'Tigerless'
};
